
<div>
    <ul id="lightSlider">
        <?php foreach ($images as $image): ?>
        <li>
            <img src="<?php echo $image->src; ?>" width="160px" />
        </li>
        <?php endforeach; ?>
    </ul>
</div>

<script type="text/javascript">
    $(document).ready(function() {
        $("#lightSlider").lightSlider(); 
    });
</script>