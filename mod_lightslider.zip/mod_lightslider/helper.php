<?php

class ModLightSliderHelper
{
    public static function getHello($params)
    {
        return 'Hello, World!';
    }
}