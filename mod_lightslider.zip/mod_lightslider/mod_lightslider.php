<?php
defined('_JEXEC') or die;

require_once dirname(__FILE__) . '/helper.php';

$document = JFactory::getDocument();

$document->addScript('js/lightslider.min.js');
$document->addStyleSheet('css/lightslider.min.css');

$config = JFactory::getConfig();
$images = $config->get('images');

//$ls = modLightSliderHelper::getHello($params);
require JModuleHelper::getLayoutPath('mod_lightslider');