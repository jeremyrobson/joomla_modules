<?php

class JFormRuleNumeric extends JFormRule
{
	protected $regex = "^\d+(\.\d+)?$";
}
