<?php

class JFormRuleString extends JFormRule
{
	protected $regex = "^[A-Za-z0-9\.\,\'\s\&\!\@\#\:\+]+$";
}

