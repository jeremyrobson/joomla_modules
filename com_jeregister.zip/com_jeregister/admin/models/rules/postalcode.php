<?php

class JFormRulePostalcode extends JFormRule
{
	protected $regex = "^[A-Za-z][0-9][A-Za-z][\s-]?[0-9][A-Za-z][0-9]$";
}
