DROP TABLE IF EXISTS `#__registration`;
DROP TABLE IF EXISTS `#__transaction`;