DROP TABLE IF EXISTS `#__registration`;
DROP TABLE IF EXISTS `#__transaction`;
DROP TABLE IF EXISTS `#__farm_profile`;