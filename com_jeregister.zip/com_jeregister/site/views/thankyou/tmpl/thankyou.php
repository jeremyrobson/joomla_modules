<?php
defined('_JEXEC') or die('Restricted access');
?>

<p>Please allow up to 3-7 business days to process online payments, and 2-3 weeds to process mailed payments.</p>

<p>Thanks!</p>

<p>The BGO Team</p>