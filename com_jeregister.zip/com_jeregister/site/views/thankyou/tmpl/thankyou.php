<?php
defined('_JEXEC') or die('Restricted access');
?>

<p>Please allow up to x days to process your payment</p>

<p>Thanks!</p>

<p>The OBG Team</p>