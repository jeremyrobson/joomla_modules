<?php
defined('_JEXEC') or die('Restricted access');
?>

<div id='map'></div>
