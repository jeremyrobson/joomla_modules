<?php

defined('_JEXEC') or die('Restricted access');

class JeregisterModelFindafarm extends JModelItem
{

}