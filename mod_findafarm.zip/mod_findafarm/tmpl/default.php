<?php
defined('_JEXEC') or die;
?>

<div id='map'></div>